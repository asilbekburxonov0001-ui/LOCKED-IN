#!/usr/bin/env bash
# Run once inside this folder. Needs Flutter 3.22+ and Android SDK.
set -e
flutter create --org com.lockedin --project-name locked_in --platforms android _gen
cp -rn _gen/. . && rm -rf _gen
flutter pub get
echo "Done. Run: flutter run   |   Release: flutter build appbundle --release"
