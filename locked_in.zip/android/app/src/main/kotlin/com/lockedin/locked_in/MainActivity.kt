package com.lockedin.locked_in

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.WindowManager
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val nm get() = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val prefs get() = getSharedPreferences("li", MODE_PRIVATE)

    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        MethodChannel(engine.dartExecutor.binaryMessenger, "lockedin/native").setMethodCallHandler { call, res ->
            when (call.method) {
                "status" -> res.success(mapOf(
                    "dnd" to nm.isNotificationPolicyAccessGranted,
                    "notif" to (Build.VERSION.SDK_INT < 33 ||
                        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED),
                    "battery" to (getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)))
                "open" -> { open(call.argument<String>("what") ?: ""); res.success(null) }
                "start" -> { start(); res.success(null) }
                "stop" -> { stop(); res.success(null) }
                else -> res.notImplemented()
            }
        }
    }

    private fun open(what: String) {
        when (what) {
            "dnd" -> startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            "notif" -> if (Build.VERSION.SDK_INT >= 33)
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            else startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
            "battery" -> startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun start() {
        if (nm.isNotificationPolicyAccessGranted) {
            if (!prefs.contains("prev")) prefs.edit().putInt("prev", nm.currentInterruptionFilter).apply()
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.also { it.screenBrightness = 0.02f }
        WindowCompat.getInsetsController(window, window.decorView).hide(WindowInsetsCompat.Type.systemBars())
        try { startLockTask() } catch (_: Exception) {}
    }

    private fun stop() {
        val prev = prefs.getInt("prev", -1)
        if (prev > 0 && nm.isNotificationPolicyAccessGranted) nm.setInterruptionFilter(prev)
        prefs.edit().remove("prev").apply()
        try { stopLockTask() } catch (_: Exception) {}
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.also { it.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE }
    }
}
