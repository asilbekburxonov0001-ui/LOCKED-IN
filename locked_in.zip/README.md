# LOCKED IN (Android, Flutter + Kotlin)

## GitHub Actions orqali AAB olish
1. Bu papkadagi hamma narsani (`.github` papkasi bilan) GitHub repo ildiziga yuklang.
2. Actions -> **Create upload keystore (run ONCE)** -> Run workflow.
   Tugagach `keystore-secrets` artifact'ni yuklab oling (ichida `secrets.txt` va `upload-keystore.jks`). Ularni xavfsiz joyda saqlang!
3. Repo -> Settings -> Secrets and variables -> Actions -> New repository secret:
   - `KEYSTORE_PASSWORD` = secrets.txt dagi parol
   - `KEYSTORE_BASE64` = secrets.txt dagi uzun matn
4. Actions -> **Build signed AAB** -> Run workflow. Natija: artifact `locked-in-release-aab` (app-release.aab).
5. Play Console -> Closed testing -> shu AAB ni yuklang.

versionCode har run'da avtomatik oshadi (github run number).
Local: `./setup.sh`, `flutter run`.
