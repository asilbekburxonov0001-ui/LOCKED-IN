import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

const ch = MethodChannel('lockedin/native');
const bone = Color(0xFFF1EDE4), hot = Color(0xFFFF3D2E), mute = Color(0xFF77746D);
const msgs = [
  'Locked in. Nothing else matters right now.',
  'Every minute here is a vote for who you’re becoming.',
  'Discipline is doing it when you don’t feel like it.',
  'Your phone can wait. Your goals can’t.',
  'Deep work is rare. You’re doing it.',
  'Stay with the hard part. That’s where the growth is.',
  'Nobody is coming to do this for you. Keep going.',
  'Small focused hours build big lives.',
  'The urge to check will pass. Stay.',
  'You’re further along than when you started.',
];
late SharedPreferences sp;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  sp = await SharedPreferences.getInstance();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  // A session still marked active at launch means the app was killed mid-session: it counts as broken.
  if (sp.getInt('endAt') != null) {
    await record(sp.getInt('min') ?? 0, false);
    await sp.remove('endAt');
    try { await ch.invokeMethod('stop'); } catch (_) {}
  }
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: Colors.black,
      colorScheme: const ColorScheme.dark(primary: bone, secondary: hot, surface: Colors.black)),
    home: const Gate()));
}

Future<void> record(int min, bool ok) async {
  final l = sp.getStringList('log') ?? [];
  l.add('${DateTime.now().millisecondsSinceEpoch}|$min|${ok ? 1 : 0}');
  await sp.setStringList('log', l);
}

({int today, int streak}) stats() {
  String k(DateTime d) => '${d.year}-${d.month}-${d.day}';
  final days = <String>{};
  var today = 0;
  for (final s in sp.getStringList('log') ?? <String>[]) {
    final p = s.split('|');
    if (p[2] != '1') continue;
    final d = DateTime.fromMillisecondsSinceEpoch(int.parse(p[0]));
    days.add(k(d));
    if (k(d) == k(DateTime.now())) today += int.parse(p[1]);
  }
  var d = DateTime.now();
  if (!days.contains(k(d))) d = d.subtract(const Duration(days: 1));
  var st = 0;
  while (days.contains(k(d))) { st++; d = d.subtract(const Duration(days: 1)); }
  return (today: today, streak: st);
}

/// Permission gate: LOCK IN stays unreachable until every permission is granted.
class Gate extends StatefulWidget {
  const Gate({super.key});
  @override State<Gate> createState() => _GateState();
}

class _GateState extends State<Gate> with WidgetsBindingObserver {
  Map<String, bool> st = {};
  @override void initState() { super.initState(); WidgetsBinding.instance.addObserver(this); refresh(); }
  @override void dispose() { WidgetsBinding.instance.removeObserver(this); super.dispose(); }
  @override void didChangeAppLifecycleState(AppLifecycleState s) { if (s == AppLifecycleState.resumed) refresh(); }
  Future<void> refresh() async {
    final r = await ch.invokeMapMethod<String, bool>('status');
    if (mounted) setState(() => st = r ?? {});
  }

  @override
  Widget build(BuildContext context) {
    if (st.isEmpty) return const Scaffold();
    if (st.values.every((v) => v)) return const Home();
    const items = [
      ('dnd', 'Do Not Disturb access', 'Silences calls and messages during a session.'),
      ('notif', 'Notifications', 'Shows the session status.'),
      ('battery', 'Unrestricted battery', 'Stops the phone from killing the timer.'),
    ];
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('LOCKED IN', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            const Text('Grant every permission to unlock the app.', style: TextStyle(color: mute)),
            const SizedBox(height: 28),
            for (final i in items)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Icon(st[i.$1]! ? Icons.check_circle : Icons.lock_outline, color: st[i.$1]! ? bone : hot),
                title: Text(i.$2),
                subtitle: Text(i.$3, style: const TextStyle(color: mute)),
                trailing: st[i.$1]! ? null : TextButton(onPressed: () => ch.invokeMethod('open', {'what': i.$1}), child: const Text('Grant')),
              ),
          ]),
        ),
      ),
    );
  }
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int m = 25;
  double acc = 0;

  void drag(DragUpdateDetails d) {
    acc -= d.delta.dx / 14;
    final steps = acc.truncate();
    if (steps == 0) return;
    acc -= steps;
    final n = (m + steps).clamp(5, 180);
    if (n != m) { HapticFeedback.selectionClick(); setState(() => m = n); }
  }

  @override
  Widget build(BuildContext context) {
    final s = stats();
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(22),
          child: Column(children: [
            Row(children: [
              Image.asset('assets/logo_mark.png', width: 28),
              const SizedBox(width: 10),
              const Text('LOCKED IN', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const Spacer(),
              Text('${s.today} min today\n${s.streak} day streak', textAlign: TextAlign.right, style: const TextStyle(color: mute, fontSize: 13)),
            ]),
            const Spacer(),
            Text('$m', style: const TextStyle(fontSize: 150, fontWeight: FontWeight.w200, letterSpacing: -8, height: 1)),
            const Text('minutes', style: TextStyle(color: mute)),
            const SizedBox(height: 28),
            GestureDetector(
              onHorizontalDragUpdate: drag,
              child: CustomPaint(size: const Size(double.infinity, 70), painter: Ruler(m)),
            ),
            const SizedBox(height: 16),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              for (final p in [25, 45, 60, 90])
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(foregroundColor: m == p ? bone : mute, side: BorderSide(color: m == p ? bone : const Color(0xFF2A2927))),
                    onPressed: () => setState(() => m = p),
                    child: Text('$p'),
                  ),
                ),
            ]),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: bone, foregroundColor: Colors.black, padding: const EdgeInsets.all(22), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
                icon: const Icon(Icons.lock),
                label: const Text('LOCK IN', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LockPage(m))).then((_) => setState(() {})),
              ),
            ),
            const SizedBox(height: 10),
            const Text('Leave the screen for more than 5 seconds and the session breaks.', textAlign: TextAlign.center, style: TextStyle(color: mute, fontSize: 12)),
          ]),
        ),
      ),
    );
  }
}

class Ruler extends CustomPainter {
  final int m;
  Ruler(this.m);
  @override
  void paint(Canvas c, Size s) {
    final p = Paint()..strokeCap = StrokeCap.round..strokeWidth = 2;
    for (var i = -40; i <= 40; i++) {
      final v = m + i;
      if (v < 5 || v > 180) continue;
      final h = v % 15 == 0 ? 42.0 : v % 5 == 0 ? 30.0 : 18.0;
      p.color = v % 15 == 0 ? bone : v % 5 == 0 ? const Color(0xFF5A5852) : const Color(0xFF2A2927);
      final x = s.width / 2 + i * 14;
      c.drawLine(Offset(x, 10), Offset(x, 10 + h), p);
    }
    c.drawLine(Offset(s.width / 2, 0), Offset(s.width / 2, 58), Paint()..color = hot..strokeWidth = 3..strokeCap = StrokeCap.round);
  }
  @override bool shouldRepaint(Ruler o) => o.m != m;
}

class LockPage extends StatefulWidget {
  final int min;
  const LockPage(this.min, {super.key});
  @override State<LockPage> createState() => _LockState();
}

class _LockState extends State<LockPage> with WidgetsBindingObserver, SingleTickerProviderStateMixin {
  late final DateTime end;
  late final AnimationController q;
  Timer? t;
  DateTime? away;
  int left = 0;
  String? res;
  bool ok = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    end = DateTime.now().add(Duration(minutes: widget.min));
    left = widget.min * 60;
    sp.setInt('endAt', end.millisecondsSinceEpoch);
    sp.setInt('min', widget.min);
    q = AnimationController(vsync: this, duration: const Duration(seconds: 5))
      ..addStatusListener((s) { if (s == AnimationStatus.completed) finish(false, 'You gave up.'); });
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    ch.invokeMethod('start');
    t = Timer.periodic(const Duration(milliseconds: 250), (_) => tick());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    t?.cancel();
    q.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  void tick() {
    if (res != null) return;
    final l = (end.difference(DateTime.now()).inMilliseconds / 1000).ceil();
    if (l <= 0) { finish(true, null); return; }
    setState(() => left = l);
  }

  Future<void> finish(bool good, String? why) async {
    if (res != null) return;
    res = why ?? '';
    ok = good;
    t?.cancel();
    q.stop();
    try { await ch.invokeMethod('stop'); } catch (_) {}
    await sp.remove('endAt');
    await record(widget.min, good);
    if (good) HapticFeedback.heavyImpact();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    if (mounted) setState(() {});
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (res != null) return;
    if (s == AppLifecycleState.paused || s == AppLifecycleState.hidden) away ??= DateTime.now();
    if (s == AppLifecycleState.resumed && away != null) {
      final g = DateTime.now().difference(away!);
      away = null;
      if (g.inSeconds > 5) finish(false, 'You left the screen for ${g.inSeconds} seconds.');
    }
  }

  String fmt(int s) {
    String p(int n) => n.toString().padLeft(2, '0');
    final h = s ~/ 3600;
    return '${h > 0 ? '$h:' : ''}${p(s % 3600 ~/ 60)}:${p(s % 60)}';
  }

  @override
  Widget build(BuildContext context) {
    final done = res != null;
    if (done) {
      return PopScope(
        canPop: true,
        child: Scaffold(
          body: Center(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(ok ? 'Done.' : 'Broken.', style: TextStyle(fontSize: 38, fontWeight: FontWeight.w900, color: ok ? bone : hot)),
              const SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 32),
                child: Text(ok ? '${widget.min} minutes locked in. That’s real focus.' : '$res This one doesn’t count.', textAlign: TextAlign.center, style: const TextStyle(color: mute, fontSize: 16)),
              ),
              const SizedBox(height: 28),
              FilledButton(
                style: FilledButton.styleFrom(backgroundColor: bone, foregroundColor: Colors.black, padding: const EdgeInsets.symmetric(horizontal: 36, vertical: 16)),
                onPressed: () => Navigator.pop(context),
                child: const Text('Back', style: TextStyle(fontWeight: FontWeight.w900)),
              ),
            ]),
          ),
        ),
      );
    }
    final k = left <= 60 ? -1 : (widget.min * 60 - left) ~/ 75;
    final msg = k == -1 ? 'Final minute. Finish strong.' : msgs[k % msgs.length];
    final minute = left ~/ 60;
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(children: [
          AnimatedAlign(
            duration: const Duration(seconds: 2),
            alignment: Alignment(sin(minute * 1.7) * .25, cos(minute * 2.3) * .25),
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTapDown: (_) => q.forward(from: 0),
              onTapUp: (_) => q.reset(),
              onTapCancel: () => q.reset(),
              child: Padding(
                padding: const EdgeInsets.all(40),
                child: Text(fmt(left), style: const TextStyle(fontSize: 84, fontWeight: FontWeight.w200, color: Color(0xFF4A4946), letterSpacing: -2)),
              ),
            ),
          ),
          Positioned(
            left: 0, right: 0, bottom: 150,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 36),
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 600),
                child: Text(msg, key: ValueKey(msg), textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, color: Color(0xFF5F5C55), height: 1.45)),
              ),
            ),
          ),
          const Positioned(left: 0, right: 0, bottom: 28, child: Text('Hold the timer for 5 seconds to quit', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Color(0xFF2D2C2A)))),
          Positioned(left: 0, bottom: 0, child: AnimatedBuilder(animation: q, builder: (_, __) => Container(height: 3, width: MediaQuery.of(context).size.width * q.value, color: hot))),
        ]),
      ),
    );
  }
}
