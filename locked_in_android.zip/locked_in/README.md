# LOCKED IN (Android, Flutter + Kotlin)
1. `./setup.sh` (generates the Gradle scaffolding around these files, never overwrites them)
2. `flutter run` on a real Android phone
3. Release: create a keystore, add signing config, `flutter build appbundle --release`
Icons: `store/playstore_icon_512.png`, feature graphic `store/feature_graphic_1024x500.png`, vector `assets/logo.svg`.

Included: permission gate (DND, notifications, battery), black lock screen, screen pinning, DND during session, keep-awake,
break detection (5 s grace), hold-5s quit, restore-after-kill (counts as broken), history/streak.
NOT included yet: foreground service, exact-alarm, history screen, settings, tests, localization, CI, privacy policy.
Screen pinning shows Android’s own confirmation the first time. Untested: no Flutter SDK was available when this was generated.
